export const mockCartItems = [
    {
        id: "form-001",
        name: "Data Science pour la Santé Publique",
        price: 299.99,
        quantity: 2,
        image: "https://placehold.co/150x150/E0E7FF/3730A3?text=Formation+1"
    },
    {
        id: "art-001",
        name: "Fibromyalgie et VIH",
        price: 19.99,
        quantity: 1,
        image: "https://placehold.co/150x150/FEE2E2/991B1B?text=Article+1"
    },
    {
        id: "book-001",
        name: "Épidémiologie Pratique",
        price: 89.99,
        quantity: 1,
        image: "https://placehold.co/150x150/D1FAE5/065F46?text=Livre+1"
    }
];